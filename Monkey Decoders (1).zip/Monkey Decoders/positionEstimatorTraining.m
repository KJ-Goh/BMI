function modelParameters = positionEstimatorTraining(training_data)

% Parameters
binSize = 20;    % ms
minT    = 320;   % first decoding time
nBins   = 1;    % history length
lambdaV = 1e3;   % ridge for velocity model
lambdaP = 1e3;   % ridge for absolute-position correction
beta    = 0.10;  % blend weight for absolute-position correction

nTrials  = size(training_data,1);
nDir     = size(training_data,2);
nNeurons = size(training_data(1,1).spikes,1);

clfT = minT;

% Direction classifier stats
dirMeanCounts = zeros(nNeurons, nDir);
dirVarCounts  = zeros(nNeurons, nDir);

% Per-direction models
BvCell     = cell(1, nDir);   % velocity decoder
BpCell     = cell(1, nDir);   % absolute position decoder
muFeatCell = cell(1, nDir);   % feature means
sdFeatCell = cell(1, nDir);   % feature stds

for k = 1:nDir

    clfCounts = zeros(nNeurons, nTrials);
    nSamples = 0;

    for n = 1:nTrials
        spikes = training_data(n,k).spikes;
        T = size(spikes,2);

        tEnd = min(clfT, T);
        clfCounts(:,n) = sum(spikes(:,1:tEnd), 2);

        times = minT:binSize:T;
        times = times(times - binSize >= 1);
        nSamples = nSamples + numel(times);
    end

    dirMeanCounts(:,k) = mean(clfCounts, 2);
    dirVarCounts(:,k)  = var(clfCounts, 0, 2) + 1; 

    
    D = 1 + 2 + nNeurons*nBins;   
    X  = zeros(nSamples, D);
    Yv = zeros(nSamples, 2);      % [dx dy]
    Yp = zeros(nSamples, 2);      % [x y]

    row = 0;

    
    for n = 1:nTrials
        spikes  = training_data(n,k).spikes;
        handPos = training_data(n,k).handPos;
        T = size(spikes,2);

        cs = [zeros(nNeurons,1), cumsum(spikes,2)];

        times = minT:binSize:T;
        times = times(times - binSize >= 1);

        for ii = 1:numel(times)
            t = times(ii);
            row = row + 1;

            prevX = handPos(1, t-binSize);
            prevY = handPos(2, t-binSize);

            featCounts = zeros(1, nNeurons*nBins);

            for jb = 1:nBins
                tEnd = t - (jb-1)*binSize;
                tBeg = tEnd - binSize + 1;

                if tBeg < 1
                    counts = zeros(nNeurons,1);
                else
                    counts = cs(:, tEnd+1) - cs(:, tBeg);
                end

                idxBeg = (jb-1)*nNeurons + 1;
                idxEnd = jb*nNeurons;
                featCounts(idxBeg:idxEnd) = counts';
            end

            X(row,:) = [1, prevX, prevY, featCounts];

            dx = handPos(1,t) - handPos(1,t-binSize);
            dy = handPos(2,t) - handPos(2,t-binSize);

            Yv(row,:) = [dx, dy];
            Yp(row,:) = [handPos(1,t), handPos(2,t)];
        end
    end

    muFeat = mean(X, 1);
    sdFeat = std(X, 0, 1) + 1e-8;

    muFeat(1) = 0;  
    sdFeat(1) = 1;

    Xz = (X - muFeat) ./ sdFeat;
    Xz(:,1) = 1;

    I = eye(D);
    I(1,1) = 0;  
    Bv = (Xz' * Xz + lambdaV * I) \ (Xz' * Yv);
    Bp = (Xz' * Xz + lambdaP * I) \ (Xz' * Yp);

    BvCell{k}     = Bv;
    BpCell{k}     = Bp;
    muFeatCell{k} = muFeat;
    sdFeatCell{k} = sdFeat;
end

modelParameters.binSize = binSize;
modelParameters.minT    = minT;
modelParameters.nBins   = nBins;
modelParameters.nNeurons = nNeurons;
modelParameters.nDir    = nDir;

modelParameters.lambdaV = lambdaV;
modelParameters.lambdaP = lambdaP;
modelParameters.beta    = beta;

modelParameters.dirMeanCounts = dirMeanCounts;
modelParameters.dirVarCounts  = dirVarCounts;

modelParameters.BvCell     = BvCell;
modelParameters.BpCell     = BpCell;
modelParameters.muFeatCell = muFeatCell;
modelParameters.sdFeatCell = sdFeatCell;

end