function [x, y] = positionEstimator(test_data, modelParameters)

persistent currentTrialId currentDir

if isempty(currentTrialId)
    currentTrialId = -1;
    currentDir = 1;
end

spikes = test_data.spikes;
t = size(spikes,2);

binSize  = modelParameters.binSize;
nBins    = modelParameters.nBins;
nNeurons = modelParameters.nNeurons;
nDir     = modelParameters.nDir;
beta     = modelParameters.beta;

if isempty(test_data.decodedHandPos)
    countsClf = sum(spikes, 2);

    scores = zeros(1, nDir);
    for k = 1:nDir
        mu = modelParameters.dirMeanCounts(:,k);
        vv = modelParameters.dirVarCounts(:,k);
        diffVec = countsClf - mu;
        scores(k) = sum((diffVec.^2) ./ vv);  
    end

    [~, currentDir] = min(scores);
    currentTrialId = test_data.trialId;
end

if isempty(test_data.decodedHandPos)
    prevXY = test_data.startHandPos;
else
    prevXY = test_data.decodedHandPos(:,end);
end

cs = [zeros(nNeurons,1), cumsum(spikes,2)];
featCounts = zeros(1, nNeurons*nBins);

for jb = 1:nBins
    tEnd = t - (jb-1)*binSize;
    tBeg = tEnd - binSize + 1;

    if tBeg < 1
        counts = zeros(nNeurons,1);
    else
        counts = cs(:, tEnd+1) - cs(:, tBeg);
    end

    idxBeg = (jb-1)*nNeurons + 1;
    idxEnd = jb*nNeurons;
    featCounts(idxBeg:idxEnd) = counts';
end

xFeat = [1, prevXY(1), prevXY(2), featCounts];


muFeat = modelParameters.muFeatCell{currentDir};
sdFeat = modelParameters.sdFeatCell{currentDir};

xFeat = (xFeat - muFeat) ./ sdFeat;
xFeat(1) = 1;


predVel = xFeat * modelParameters.BvCell{currentDir};   
predAbs = xFeat * modelParameters.BpCell{currentDir};   

intPos = prevXY + predVel';

newXY = (1 - beta) * intPos + beta * predAbs';

x = newXY(1);
y = newXY(2);

end